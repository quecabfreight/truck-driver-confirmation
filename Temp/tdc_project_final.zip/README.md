# QueCab AdbS – Truck Driver Confirmation

This tool generates QR-based confirmations to help prevent double brokering. Includes:
- Driver form (index.html)
- Verification page (verify.html)
- Email backend (server.js)
